{{/* SPDX-License-Identifier: Apache-2.0 */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "openhab.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "openhab.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart label value.
*/}}
{{- define "openhab.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "openhab.labels" -}}
helm.sh/chart: {{ include "openhab.chart" . }}
{{ include "openhab.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Namespace for chart-managed namespaced resources.
*/}}
{{- define "openhab.namespace" -}}
{{- .Values.namespaceOverride | default .Release.Namespace }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "openhab.selectorLabels" -}}
app.kubernetes.io/name: {{ include "openhab.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "openhab.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "openhab.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Validate replicaCount - openHAB does not support clustering.
*/}}
{{- define "openhab.validateReplicaCount" -}}
{{- if gt (int .Values.replicaCount) 1 }}
{{- fail "openHAB does not support horizontal scaling. replicaCount MUST be 1. Running multiple replicas against the same persistent storage will corrupt data." }}
{{- end }}
{{- end }}

{{/*
Validate admin secret configuration.
*/}}
{{- define "openhab.validateAdmin" -}}
{{- if and .Values.admin.secretEnabled (not .Values.admin.password) (not .Values.admin.existingSecret) }}
{{- fail "admin.password is required when admin.secretEnabled is true and admin.existingSecret is not set." }}
{{- end }}
{{- end }}

{{/*
Validate ConfigMap sync configuration.
*/}}
{{- define "openhab.validateConfigMaps" -}}
{{- $hasSitemaps := and .Values.configMaps.sitemaps.enabled (gt (len (.Values.configMaps.sitemaps.files | default dict)) 0) }}
{{- $hasThings := and .Values.configMaps.things.enabled (gt (len (.Values.configMaps.things.files | default dict)) 0) }}
{{- $hasItems := and .Values.configMaps.items.enabled (gt (len (.Values.configMaps.items.files | default dict)) 0) }}
{{- if and (or $hasSitemaps $hasThings $hasItems) (not .Values.persistence.conf.enabled) }}
{{- fail "configMaps require persistence.conf.enabled=true because files are copied into the writable /openhab/conf PVC before startup." }}
{{- end }}
{{- end }}

{{/*
Validate pod labels do not override immutable selector labels.
*/}}
{{- define "openhab.validatePodLabels" -}}
{{- $podLabels := .Values.podLabels | default dict -}}
{{- if hasKey $podLabels "app.kubernetes.io/name" -}}
{{- fail "podLabels must not override the selector label app.kubernetes.io/name" -}}
{{- end -}}
{{- if hasKey $podLabels "app.kubernetes.io/instance" -}}
{{- fail "podLabels must not override the selector label app.kubernetes.io/instance" -}}
{{- end -}}
{{- end }}

{{/*
Validate persistent volume configuration.
*/}}
{{- define "openhab.validatePersistence" -}}
{{- $volumes := dict "userdata" .Values.persistence.userdata "conf" .Values.persistence.conf "addons" .Values.persistence.addons }}
{{- range $name, $volume := $volumes }}
{{- if and (not $volume.enabled) (or $volume.existingClaim $volume.subPath) }}
{{- fail (printf "persistence.%s must be enabled when existingClaim or subPath is configured." $name) }}
{{- end }}
{{- if and $volume.subPath (or (hasPrefix "/" $volume.subPath) (eq $volume.subPath ".") (eq $volume.subPath "..") (regexMatch "(^|/)\\.\\.(/|$)" $volume.subPath)) }}
{{- fail (printf "persistence.%s.subPath must be a relative path without traversal segments." $name) }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Resolve the admin secret name.
*/}}
{{- define "openhab.adminSecretName" -}}
{{- if .Values.admin.existingSecret }}
{{- .Values.admin.existingSecret }}
{{- else }}
{{- printf "%s-admin" (include "openhab.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Resolve the userdata PVC name.
*/}}
{{- define "openhab.userdataPvcName" -}}
{{- if .Values.persistence.userdata.existingClaim }}
{{- .Values.persistence.userdata.existingClaim }}
{{- else }}
{{- printf "%s-userdata" (include "openhab.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Resolve the userdata Kubernetes volume name.
*/}}
{{- define "openhab.userdataVolumeName" -}}
userdata
{{- end }}

{{/*
Resolve the conf PVC name.
*/}}
{{- define "openhab.confPvcName" -}}
{{- if .Values.persistence.conf.existingClaim }}
{{- .Values.persistence.conf.existingClaim }}
{{- else }}
{{- printf "%s-conf" (include "openhab.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Resolve the conf Kubernetes volume name.
*/}}
{{- define "openhab.confVolumeName" -}}
{{- $confClaim := include "openhab.confPvcName" . -}}
{{- $userdataClaim := include "openhab.userdataPvcName" . -}}
{{- if and .Values.persistence.userdata.enabled (eq $confClaim $userdataClaim) -}}
userdata
{{- else -}}
conf
{{- end -}}
{{- end }}

{{/*
Resolve the addons PVC name.
*/}}
{{- define "openhab.addonsPvcName" -}}
{{- if .Values.persistence.addons.existingClaim }}
{{- .Values.persistence.addons.existingClaim }}
{{- else }}
{{- printf "%s-addons" (include "openhab.fullname" .) }}
{{- end }}
{{- end }}

{{/*
Resolve the addons Kubernetes volume name.
*/}}
{{- define "openhab.addonsVolumeName" -}}
{{- $addonsClaim := include "openhab.addonsPvcName" . -}}
{{- $userdataClaim := include "openhab.userdataPvcName" . -}}
{{- $confClaim := include "openhab.confPvcName" . -}}
{{- if and .Values.persistence.userdata.enabled (eq $addonsClaim $userdataClaim) -}}
userdata
{{- else if and .Values.persistence.conf.enabled (eq $addonsClaim $confClaim) -}}
conf
{{- else -}}
addons
{{- end -}}
{{- end }}
